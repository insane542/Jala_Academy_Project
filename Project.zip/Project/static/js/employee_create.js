// Add the down class to the arrow icon when the page loads
document.getElementById('employee-arrow').classList.add('down'); // Employee menu arrow should point down by default
// Open the Employee submenu by default
document.getElementById('employee-submenu').classList.add('open');

// Ensure Menu is selected in the Employee menu by default
document.querySelectorAll('#employee-submenu .menu-item').forEach(item => {
    item.classList.remove('active'); // Deselect all
});

// Toggle the down class when the Employee menu item is clicked
document.getElementById('employee-menu').addEventListener('click', function() {
    var employeeSubmenu = document.getElementById('employee-submenu');
    var employeeArrow = document.getElementById('employee-arrow');

    // Close the More submenu if it's open
    var moreSubmenu = document.getElementById('more-submenu');
    var moreArrow = document.getElementById('more-arrow');
    if (moreSubmenu.classList.contains('open')) {
        moreSubmenu.classList.remove('open');
        moreArrow.classList.remove('down');
        moreArrow.classList.add('left'); // Adjust based on your design
        document.getElementById('more-menu').classList.remove('active');
    }

    // Toggle Employee submenu
    employeeSubmenu.classList.toggle('open');
    employeeArrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    this.classList.add('active');
});

// For Home item, ensure it gets activated when clicked
document.querySelector('.home').addEventListener('click', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));
    this.classList.add('active'); 
});

// Toggle the down class when the More menu item is clicked
document.getElementById('more-menu').addEventListener('click', function() {
    var moreSubmenu = document.getElementById('more-submenu');
    var moreArrow = document.getElementById('more-arrow');

    // Close the Employee submenu if it's open
    var employeeSubmenu = document.getElementById('employee-submenu');
    var employeeArrow = document.getElementById('employee-arrow');
    if (employeeSubmenu.classList.contains('open')) {
        employeeSubmenu.classList.remove('open');
        employeeArrow.classList.remove('down');
        employeeArrow.classList.add('left'); 
        document.getElementById('employee-menu').classList.remove('active');
    }

    // Toggle More submenu
    moreSubmenu.classList.toggle('open');
    moreArrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked More menu item
    this.classList.add('active');
});

// Initializing the date picker functionality
document.addEventListener('DOMContentLoaded', function() {
    const realDatePicker = document.getElementById('realDatePicker');
    const displayDate = document.getElementById('displayDate');
    const calendarIcon = document.getElementById('calendar-icon');

    // When real date picker value changes
    realDatePicker.addEventListener('change', function() {
        const dateValue = new Date(this.value);
        if (!isNaN(dateValue.getTime())) {
            const formattedDate = dateValue.toLocaleDateString('en-GB'); // Format as dd/mm/yyyy
            displayDate.value = formattedDate; // Set the formatted date in the display field
        }
    });

    // Click event on calendar icon to trigger the real date picker input focus
    calendarIcon.addEventListener('click', function() {
        realDatePicker.click(); 
    });
});

function updateCities() {
    const countrySelect = document.getElementById('country');
    const citySelect = document.getElementById('city');
    const selectedCountry = countrySelect.value;

    // Clear current options
    citySelect.innerHTML = '<option value="">--Select City--</option>';

    let cities = [];
    switch (selectedCountry) {
        case 'Bangladesh':
            cities = ['Bogra', 'Brahmanbaria', 'Cox\'s Bazar', 'Faridpur', 'Jessore', 'Kushtia', 'Nawabganj', 'Siraiganj', 'Tangail'];
            break;
        case 'Canada':
            cities = ['Brant', 'Burlington', 'Cornwall', 'Hamilton', 'North Bay', 'Ottawa', 'Sarnia', 'Toronto'];
            break;
        case 'China':
            cities = ['Beijing', 'Bozhou', 'Chizhou', 'Hong Kong', 'Jeishou', 'Longhai', 'Longnan', 'Macau', 'Shanghai', 'Suzhou', 'Yumen'];
            break;
        case 'France':
            cities = ['Bron', 'Castres', 'Lyon', 'Marseille', 'Nantes', 'Paris', 'Poissy', 'Reims', 'Roanne'];
            break;
        case 'India':
            cities = ['Ahmedabad', 'Bhopal', 'Chennai', 'Delhi', 'Hyderabad', 'Kolkata', 'Mumbai', 'Pune', 'Rajkot', 'Surat'];
            break;
        case 'Japan':
            cities = ['Hiroshima', 'Kasugai', 'Maebashi', 'Midori', 'Nagasaki', 'Nagoya', 'Takasaki', 'Yamagata', 'Yatomi'];
            break;
        case 'Nepal':
            cities = ['Bharatpur', 'Chandrapur', 'Damak', 'Godawari', 'Itahari', 'Janakpur', 'Kathmandu', 'Lalitpur', 'Nepalgunj', 'Siraha', 'Tikapur', 'Tokha'];
            break;
        case 'Sri Lanka':
            cities = ['Colombo', 'Dambulla', 'Galle', 'Kalmunai', 'Kandy', 'Ratnapura', 'Vavuniya'];
            break;
        case 'UK':
            cities = ['Bangor', 'Derby', 'Durham', 'Nottingham', 'Perth', 'Sunderland'];
            break;
        case 'USA':
            cities = ['California', 'Chicago', 'Florida', 'Hawaii', 'New Jersey', 'New York', 'Texas', 'Washington'];
            break;
    }

    cities.forEach(city => {
        const option = document.createElement('option');
        option.value = city;
        option.textContent = city;
        citySelect.appendChild(option);
    });

    // Enable city select if a country is selected, otherwise disable it
    citySelect.disabled = !selectedCountry;
}

function toggleOtherCityInput() {
    const checkbox = document.getElementById('other-city');
    const inputContainer = document.getElementById('otherCityContainer');
    const citySelect = document.getElementById('city');

    inputContainer.style.display = checkbox.checked ? 'flex' : 'none'; 
    if (!checkbox.checked) {
        document.getElementById('other-city-input').value = ''; 
    }

    // Disable city select when checkbox is checked, enable when unchecked
    citySelect.disabled = checkbox.checked;
}

// Enter Validation and Popup Javascript below:
function validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

function validateMobile(mobile) {
    const regex = /^\d{10}$/; // Check for 10 digits
    return regex.test(mobile);
}

function validateForm() {
    const email = document.getElementById('email').value;
    const mobile = document.getElementById('mobile').value;
    const emailError = document.getElementById('emailError');
    const mobileError = document.getElementById('mobileError');

    // Reset error messages
    emailError.style.display = 'none';
    mobileError.style.display = 'none';

    let valid = true;

    if (!validateEmail(email)) {
        emailError.style.display = 'block';
        valid = false;
    }

    if (!validateMobile(mobile)) {
        mobileError.style.display = 'block';
        valid = false;
    }

    return valid; // Return the validation result
}

function handleSave(event) {
    // Prevent the default form submission behavior
    event.preventDefault();

    const isValid = validateForm(); // Call validateForm to check validation

    if (isValid) {
        // Show success popup
        const successPopup = document.getElementById('successPopup');
        successPopup.classList.add('show');

        // POPUP hids in 3 seconds
        setTimeout(() => {
            successPopup.classList.remove('show');
        }, 3000);

        document.getElementById('createForm').submit();

    } else {
        // Show error popup
        const errorPopup = document.getElementById('errorPopup');
        errorPopup.classList.add('show');

        // POPUP hids in 3 seconds
        setTimeout(() => {
            errorPopup.classList.remove('show');
        }, 3000);
    }
}

function closePopup(popupId) {
    document.getElementById(popupId).classList.remove('show');
}
