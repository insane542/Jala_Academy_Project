// Add the down class to the arrow icon when the page loads
document.getElementById('employee-arrow').classList.add('left'); // Employee should be closed by default
document.getElementById('more-arrow').classList.add('down'); // More menu arrow should point down by default

// Open More submenu by default
document.getElementById('more-submenu').classList.add('open');

// Ensure Menu is selected in the More menu by default
document.querySelectorAll('#more-submenu .menu-item').forEach(item => {
    item.classList.remove('active'); // Deselect all
});
document.querySelector('#more-submenu .menu-item:nth-child(6)').classList.add('active');

// Toggle down class when the Employee menu item is clicked
document.getElementById('employee-menu').addEventListener('click', function() {
    var employeeSubmenu = document.getElementById('employee-submenu');
    var employeeArrow = document.getElementById('employee-arrow');
    var moreSubmenu = document.getElementById('more-submenu');
    var moreArrow = document.getElementById('more-arrow');
    
    // Toggle Employee submenu open and arrow down
    employeeSubmenu.classList.toggle('open');
    employeeArrow.classList.toggle('down');
    
    // Close More menu if open
    moreSubmenu.classList.remove('open');
    moreArrow.classList.remove('down');
    moreArrow.classList.add('left');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked Employee menu item
    this.classList.add('active');
});

// Toggle the down class when the More menu item is clicked
document.getElementById('more-menu').addEventListener('click', function() {
    var moreSubmenu = document.getElementById('more-submenu');
    var moreArrow = document.getElementById('more-arrow');
    var employeeSubmenu = document.getElementById('employee-submenu');
    var employeeArrow = document.getElementById('employee-arrow');
    
    // Toggle More submenu open and arrow down
    moreSubmenu.classList.toggle('open');
    moreArrow.classList.toggle('left');
    moreArrow.classList.toggle('down');

    // Close Employee menu if open
    employeeSubmenu.classList.remove('open');
    employeeArrow.classList.remove('down');
    employeeArrow.classList.add('left');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked More menu item
    this.classList.add('active');
});

// For Home item, ensure it gets activated when clicked
document.querySelector('.home').addEventListener('click', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));
    this.classList.add('active'); 
});

// Image Delete and Update Name 
var slider = document.getElementById("myRange");
var output = document.getElementById("sliderValue");
var tooltip = document.getElementById("sliderTooltip");

slider.oninput = function() {
    output.innerHTML = this.value;
    tooltip.innerHTML = this.value;
    var value = (this.value - this.min) / (this.max - this.min) * 100;
    
    // Update background to show blue on the left and grey on the right
    this.style.background = 'linear-gradient(to right, #007bff 0%, #007bff ' + value + '%, #ddd ' + value + '%, #ddd 100%)';

    // Customizing 0osition the tooltip directly above the slider thumb
    var sliderRect = this.getBoundingClientRect();
    var tooltipWidth = tooltip.offsetWidth;
    var thumbWidth = this.offsetHeight; // Thumb is circular, width = height
    var leftOffset = value / 100 * (sliderRect.width - thumbWidth);
    tooltip.style.left = (leftOffset + thumbWidth / 2) + 'px';
}

// Show tooltip on hover
slider.onmouseover = function() {
    tooltip.style.display = 'block';
}

// Hide tooltip
slider.onmouseout = function() {
    tooltip.style.display = 'none';
}

slider.dispatchEvent(new Event('input'));