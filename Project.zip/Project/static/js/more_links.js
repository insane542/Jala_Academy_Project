// Add the down class to the arrow icon when the page loads
document.getElementById('employee-arrow').classList.add('left'); // Employee should be closed by default
document.getElementById('more-arrow').classList.add('down'); // More menu arrow should point down by default

// Open the More submenu by default
document.getElementById('more-submenu').classList.add('open');

// Menu is selected in the More menu by default
document.querySelectorAll('#more-submenu .menu-item').forEach(item => {
    item.classList.remove('active'); // Deselect all
});
document.querySelector('#more-submenu .menu-item:nth-child(9)').classList.add('active'); // Select Menu

// Toggle the down class when the Employee menu item is clicked
document.getElementById('employee-menu').addEventListener('click', function() {
    var submenu = document.getElementById('employee-submenu');
    var arrow = document.getElementById('employee-arrow');

    // More menu is closed
    document.getElementById('more-submenu').classList.remove('open');
    document.getElementById('more-arrow').classList.remove('down');
    document.getElementById('more-arrow').classList.add('left');

    // Toggle Employee submenu
    submenu.classList.toggle('open');
    arrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked Employee menu item
    this.classList.add('active');
});

// Toggle the down class when the More menu item is clicked
document.getElementById('more-menu').addEventListener('click', function() {
    var submenu = document.getElementById('more-submenu');
    var arrow = document.getElementById('more-arrow');

    // Ensure the Employee menu is closed
    document.getElementById('employee-submenu').classList.remove('open');
    document.getElementById('employee-arrow').classList.remove('down');
    document.getElementById('employee-arrow').classList.add('left');

    // Toggle More submenu
    submenu.classList.toggle('open');
    arrow.classList.toggle('left');
    arrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked More menu item
    this.classList.add('active');
});

// For Home item, ensure it gets activated when clicked
document.querySelector('.home').addEventListener('click', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));
    this.classList.add('active'); 
});

// Tab switching
const buttons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

buttons.forEach(button => {
    button.addEventListener('click', function() {
        // Remove active class from all buttons
        buttons.forEach(btn => btn.classList.remove('active'));
        // Add active class to the clicked button
        this.classList.add('active');

        // Hide all tab contents
        tabContents.forEach(content => content.classList.remove('active'));
        // Show the next tab content
        const tabId = this.getAttribute('data-tab');
        document.getElementById(tabId).classList.add('active');
    });
});
