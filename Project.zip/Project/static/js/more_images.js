// Add the down class to the arrow icon when the page loads
document.getElementById('employee-arrow').classList.add('left'); // Employee should be closed by default
document.getElementById('more-arrow').classList.add('down'); // More menu arrow should point down by default

// Open the More submenu by default
document.getElementById('more-submenu').classList.add('open');

// Ensure Menu is selected in the More menu by default
document.querySelectorAll('#more-submenu .menu-item').forEach(item => {
    item.classList.remove('active'); // Deselect all
});
document.querySelector('#more-submenu .menu-item:nth-child(5)').classList.add('active'); // Select Menu

// Toggle the Employee menu and ensure More menu is closed when Employee is active
document.getElementById('employee-menu').addEventListener('click', function() {
    var employeeSubmenu = document.getElementById('employee-submenu');
    var employeeArrow = document.getElementById('employee-arrow');
    var moreSubmenu = document.getElementById('more-submenu');
    var moreArrow = document.getElementById('more-arrow');
    
    // Toggle Employee submenu
    employeeSubmenu.classList.toggle('open');
    employeeArrow.classList.toggle('down');

    // Close More menu if open
    moreSubmenu.classList.remove('open');
    moreArrow.classList.remove('down');
    moreArrow.classList.add('left');
    
    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked Employee menu item
    this.classList.add('active');
});

// For Home item, ensure it gets activated when clicked
document.querySelector('.home').addEventListener('click', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));
    this.classList.add('active'); // Keep the active state for Home
});

// Toggle the More menu and ensure Employee menu is closed when More is active
document.getElementById('more-menu').addEventListener('click', function() {
    var moreSubmenu = document.getElementById('more-submenu');
    var moreArrow = document.getElementById('more-arrow');
    var employeeSubmenu = document.getElementById('employee-submenu');
    var employeeArrow = document.getElementById('employee-arrow');
    
    // Toggle More submenu
    moreSubmenu.classList.toggle('open');
    moreArrow.classList.toggle('left');
    moreArrow.classList.toggle('down');

    // Close Employee menu if open
    employeeSubmenu.classList.remove('open');
    employeeArrow.classList.remove('down');
    employeeArrow.classList.add('left');
    
    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked More menu item
    this.classList.add('active');
});

// Image Delete and Update Name 
function updateFileName() {
    var fileInput = document.getElementById('file-upload');
    var fileNameInput = document.getElementById('file-name');
    fileNameInput.value = fileInput.files[0].name;
}

function uploadFile() {
    var fileInput = document.getElementById('file-upload');
    var file = fileInput.files[0];
    var fileName = file.name;
    var fileExtension = fileName.split('.').pop().toLowerCase();
    var allowedExtensions = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];

    if (allowedExtensions.indexOf(fileExtension) === -1) {
        showPopup("Invalid File type. It should be jpeg, jpg, png, gif, bmp only.", true);
        return;
    }

    var reader = new FileReader();
    reader.onload = function(e) {
        var imageListContainer = document.querySelector('.image-list-container');
        var imageItem = document.createElement('div');
        imageItem.className = 'image-item';
        imageItem.innerHTML = `
            <div class="image-header">
                <span>${fileName}</span>
                <i class="fas fa-times delete-icon" onclick="removeImage(this)"></i>
            </div>
            <img src="${e.target.result}" alt="Image preview">
            <div class="image-name">${fileName}</div>
        `;
        imageListContainer.appendChild(imageItem);
        showPopup("File uploaded successfully!");
    };
    reader.readAsDataURL(file);
}

function removeImage(element) {
    var imageItem = element.parentElement.parentElement;
    imageItem.remove();
    showPopup("Image deleted successfully!");
}

function showPopup(message, isError = false) {
    var popup = document.createElement('div');
    popup.className = 'popup';
    if (isError) {
        popup.classList.add('error');
    }
    popup.innerHTML = `${message} <span class="close-btn" onclick="closePopup(this)">&times;</span>`;
    document.body.appendChild(popup);
    setTimeout(function() {
        popup.classList.add('show');
    }, 10);
    setTimeout(function() {
        popup.classList.remove('show');
        setTimeout(function() {
            popup.remove();
        }, 500);
    }, 3000); // Display for 3 seconds
}

function closePopup(element) {
    var popup = element.parentElement;
    popup.classList.remove('show');
    setTimeout(function() {
        popup.remove();
    }, 500);
}
