// Add down class to the arrow icon when the page loads
document.getElementById('employee-arrow').classList.add('left'); // Employee should be closed by default
document.getElementById('more-arrow').classList.add('down'); // More menu arrow should point down by default

// Open More submenu by default
document.getElementById('more-submenu').classList.add('open');

// Confirm Menu is selected in the More menu by default
document.querySelectorAll('#more-submenu .menu-item').forEach(item => {
    item.classList.remove('active'); // Deselect all
});
document.querySelector('#more-submenu .menu-item:nth-child(6)').classList.add('active'); // Select Menu

// Toggle down class when the Employee menu item is clicked
document.getElementById('employee-menu').addEventListener('click', function() {
    var employeeSubmenu = document.getElementById('employee-submenu');
    var employeeArrow = document.getElementById('employee-arrow');
    var moreSubmenu = document.getElementById('more-submenu');
    var moreArrow = document.getElementById('more-arrow');
    
    // Toggle Employee submenu and arrow
    employeeSubmenu.classList.toggle('open');
    employeeArrow.classList.toggle('down');
    
    // Close More menu if it's open
    moreSubmenu.classList.remove('open');
    moreArrow.classList.remove('down');
    moreArrow.classList.add('left');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked Employee menu item
    this.classList.add('active');
});

// Toggle down class when the More menu item is clicked
document.getElementById('more-menu').addEventListener('click', function() {
    var moreSubmenu = document.getElementById('more-submenu');
    var moreArrow = document.getElementById('more-arrow');
    var employeeSubmenu = document.getElementById('employee-submenu');
    var employeeArrow = document.getElementById('employee-arrow');
    
    // Toggle More submenu and arrow
    moreSubmenu.classList.toggle('open');
    moreArrow.classList.toggle('left');
    moreArrow.classList.toggle('down');

    // Close Employee menu if it's open
    employeeSubmenu.classList.remove('open');
    employeeArrow.classList.remove('down');
    employeeArrow.classList.add('left');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked More menu item
    this.classList.add('active');
});

// For Home item, ensure it gets activated when clicked
document.querySelector('.home').addEventListener('click', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));
    this.classList.add('active'); 
});

// Hover Text Changing and Resetting
function changeTooltipText() {
    var tooltipText = document.querySelector('.tooltip-text');
    tooltipText.textContent = "Thank you for being here!";
}

function resetTooltipText() {
    var tooltipText = document.querySelector('.tooltip-text');
    tooltipText.textContent = "You have not clicked this BUTTON yet. Please Click me and check the tooltip";
}
