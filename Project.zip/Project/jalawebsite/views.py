from django.http import HttpResponse
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import render, redirect
from .models import Employee

# Create your views here.
def login(request):
    return render(request, "jalawebsite/login.html")

def forgot_password(request):
    return render(request, "jalawebsite/forgot_password.html")

def admin_login(request):
    return render(request, "jalawebsite/admin_login.html")

def home_page_jala(request):
    return render(request, "jalawebsite/home_page_jala.html")

def employee_create(request):
    if request.method == 'POST':
        print(request.POST)
        print("Form is Working!!!")

        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        email = request.POST.get("email")
        mobile_no = request.POST.get("mobile_no")
        gender = request.POST.get("gender")
        birth_date = request.POST.get("birth_date")
        country = request.POST.get("country")
        city = request.POST.get("city")


        e = Employee()
        e.first_name = first_name
        e.last_name = last_name
        e.email = email
        e.mobile_no = mobile_no
        e.birth_date = birth_date
        e.gender = gender
        e.country = country
        e.city = city

        e.save()
        return redirect('/employee_search/')
    return render(request, "jalawebsite/employee_create.html")


def employee_search(request):
    name = request.GET.get('name', '').strip()  
    mobile_no = request.GET.get('mobile_no', '').strip()  

    emp_list = Employee.objects.all()

    if name and mobile_no:
        emp_list = emp_list.filter(
            (Q(first_name__icontains=name) | Q(last_name__icontains=name)) & Q(mobile_no__icontains=mobile_no)
        )
    elif name:
        emp_list = emp_list.filter(
            Q(first_name__icontains=name) | Q(last_name__icontains=name)
        )
    elif mobile_no:
        emp_list = emp_list.filter(Q(mobile_no__icontains=mobile_no))

    paginator = Paginator(emp_list, 10)  
    page_number = request.GET.get('page')  
    emp_page = paginator.get_page(page_number)  
    return render(request, "jalawebsite/employee_search.html", {'emp_page': emp_page, 'name': name, 'mobile_no': mobile_no})



def employee_update(request, id):
    emp = Employee.objects.get(pk=id)
    return render(request, "jalawebsite/employee_update.html/", {'emp': emp})

def do_employee_update(request, id):
    first_name = request.POST.get("first_name")
    last_name = request.POST.get("last_name")
    email = request.POST.get("email")
    mobile_no = request.POST.get("mobile_no")
    gender = request.POST.get("gender")
    birth_date = request.POST.get("birth_date")
    country = request.POST.get("country")
    city = request.POST.get("city")

    emp = Employee.objects.get(pk=id)
    emp.first_name = first_name
    emp.last_name = last_name
    emp.email = email
    emp.mobile_no = mobile_no
    emp.birth_date = birth_date
    emp.gender = gender
    emp.country = country
    emp.city = city

    emp.save()
    return redirect('/employee_search/')


def employee_delete(request, id):
    e = Employee.objects.get(pk=id)
    e.delete()
    return redirect('/employee_search/')


def more_tabs(request):
    return render(request, "jalawebsite/more_tabs.html")

def more_menu(request):
    return render(request, "jalawebsite/more_menu.html")

def more_collapse(request):
    return render(request, "jalawebsite/more_collapse.html")

def more_images(request):
    return render(request, "jalawebsite/more_images.html")

def more_slider(request):
    return render(request, "jalawebsite/more_slider.html")

def more_tooltips(request):
    return render(request, "jalawebsite/more_tooltips.html")

def more_popups(request):
    return render(request, "jalawebsite/more_popups.html")

def more_links(request):
    return render(request, "jalawebsite/more_links.html")

def more_css_properties(request):
    return render(request, "jalawebsite/more_css_properties.html")

def more_iframe(request):
    return render(request, "jalawebsite/more_iframe.html")

def more_autocomplete(request):
    return render(request, "jalawebsite/more_autocomplete.html")