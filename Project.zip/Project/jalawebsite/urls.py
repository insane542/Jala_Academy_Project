from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.login, name="login"),
    path('forgot_password/', views.forgot_password, name="forgot_password"),
    path('admin_login/', views.admin_login, name="admin_login"),
    path('home_page_jala/', views.home_page_jala, name="home_page_jala"),
    path('employee_create/', views.employee_create, name="employee_create"),
    path('employee_search/', views.employee_search, name="employee_search"),
    path('employee_delete/<int:id>/', views.employee_delete, name='employee_delete'),
    path('employee_update/<int:id>/', views.employee_update, name='employee_update'),
    path('do_employee_update/<int:id>/', views.do_employee_update, name='do_employee_update'),
    path('more_tabs/', views.more_tabs, name="more_tabs"),
    path('more_menu/', views.more_menu, name="more_menu"),
    path('more_collapse/', views.more_collapse, name="more_collapse"),
    path('more_images/', views.more_images, name="more_images"),
    path('more_slider/', views.more_slider, name="more_slider"),
    path('more_tooltips/', views.more_tooltips, name="more_tooltips"),
    path('more_popups/', views.more_popups, name="more_popups"),
    path('more_links/', views.more_links, name="more_links"),
    path('more_css_properties/', views.more_css_properties, name="more_css_properties"),
    path('more_iframe/', views.more_iframe, name="more_iframe"),
    path('more_autocomplete/', views.more_autocomplete, name="more_autocomplete"),
]
