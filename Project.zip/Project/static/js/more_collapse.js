// Add the left class to the Employee arrow icon when the page loads
document.getElementById('employee-arrow').classList.add('left'); // Employee should be closed by default
document.getElementById('more-arrow').classList.add('down'); // More menu arrow should point down by default

// Open the More submenu by default
document.getElementById('more-submenu').classList.add('open');

// Ensure Menu is selected in the More menu by default
document.querySelectorAll('#more-submenu .menu-item').forEach(item => {
    item.classList.remove('active'); // Deselect all
});
document.querySelector('#more-submenu .menu-item:nth-child(4)').classList.add('active'); // Select Menu

// Function to close the other menu when one is clicked
function closeOtherMenus(except) {
    if (except !== 'employee') {
        var employeeSubmenu = document.getElementById('employee-submenu');
        var employeeArrow = document.getElementById('employee-arrow');
        if (employeeSubmenu.classList.contains('open')) {
            employeeSubmenu.classList.remove('open');
            employeeArrow.classList.remove('down');
            employeeArrow.classList.add('left');
        }
    }

    if (except !== 'more') {
        var moreSubmenu = document.getElementById('more-submenu');
        var moreArrow = document.getElementById('more-arrow');
        if (moreSubmenu.classList.contains('open')) {
            moreSubmenu.classList.remove('open');
            moreArrow.classList.remove('down');
            moreArrow.classList.add('left');
        }
    }
}

// Toggle the down class when the Employee menu item is clicked
document.getElementById('employee-menu').addEventListener('click', function() {
    var submenu = document.getElementById('employee-submenu');
    var arrow = document.getElementById('employee-arrow');

    // Close the More menu if it's open
    closeOtherMenus('employee');

    // Toggle the Employee submenu
    submenu.classList.toggle('open');
    arrow.classList.toggle('down');
    arrow.classList.toggle('left');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked Employee menu item
    this.classList.add('active');
});

// For Home item, ensure it gets activated when clicked
document.querySelector('.home').addEventListener('click', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));
    this.classList.add('active'); // Keep the active state for Home
});

// Toggle the down class when the More menu item is clicked
document.getElementById('more-menu').addEventListener('click', function() {
    var submenu = document.getElementById('more-submenu');
    var arrow = document.getElementById('more-arrow');

    // Close the Employee menu if it's open
    closeOtherMenus('more');

    // Toggle the More submenu
    submenu.classList.toggle('open');
    arrow.classList.toggle('left');
    arrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked More menu item
    this.classList.add('active');
});

// Tab switching
const buttons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

buttons.forEach(button => {
    button.addEventListener('click', function() {
        // Remove active class from all buttons
        buttons.forEach(btn => btn.classList.remove('active'));
        // Add active class to the clicked button
        this.classList.add('active');

        // Hide all tab contents
        tabContents.forEach(content => content.classList.remove('active'));
        // Show the next tab content
        const tabId = this.getAttribute('data-tab');
        document.getElementById(tabId).classList.add('active');
    });
});

// Multiple Collapse tabs
document.querySelectorAll('.cc-header').forEach(header => {
    header.addEventListener('click', () => {
        header.classList.toggle('active');
        const ccContent = header.nextElementSibling;
        if (header.classList.contains('active')) {
            ccContent.style.maxHeight = ccContent.scrollHeight + 'px';
        } else {
            setTimeout(() => {
                ccContent.style.maxHeight = '0';
            }, 500); // Add 500ms delay
        }
    });
});

// Single collapse for Tab 1
const scHeaders = document.querySelectorAll('#tab1 .sc-header');

scHeaders.forEach(header => {
    header.addEventListener('click', () => {
        // Close all other collapsible items
        scHeaders.forEach(h => {
            if (h !== header && h.classList.contains('active')) {
                h.classList.remove('active');
                h.querySelector('.toggle-icon').textContent = '+';
                h.nextElementSibling.style.display = 'none';
            }
        });

        // Toggle the clicked item
        header.classList.toggle('active');
        const scContent = header.nextElementSibling;
        if (header.classList.contains('active')) {
            scContent.style.display = 'block';
            header.querySelector('.toggle-icon').textContent = '-';
        } else {
            scContent.style.display = 'none';
            header.querySelector('.toggle-icon').textContent = '+';
        }
    });
});
