from django.db import models

# Create your models here.
class Employee(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.CharField(max_length=30)
    mobile_no = models.CharField(max_length=15)
    gender = models.CharField(max_length=10)
    birth_date = models.CharField(max_length=20)
    country = models.CharField(max_length=30)
    city = models.CharField(max_length=30)