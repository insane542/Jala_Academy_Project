// Add the down class to the arrow icon when the page loads
document.getElementById('more-arrow').classList.add('down'); // More menu arrow should point down by default
// Open the More submenu by default
document.getElementById('more-submenu').classList.add('open');

// Ensure Menu is selected in the More menu by default
document.querySelectorAll('#more-submenu .menu-item').forEach(item => {
    item.classList.remove('active'); // Deselect all
});
document.querySelector('#more-submenu .menu-item:nth-child(3)').classList.add('active'); // Select Menu

// Toggle the down class when the Employee menu item is clicked
document.getElementById('employee-menu').addEventListener('click', function() {
    var submenu = document.getElementById('employee-submenu');
    var arrow = document.getElementById('employee-arrow');
    submenu.classList.toggle('open');
    arrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked Employee menu item
    this.classList.add('active');
});

// For Home item, ensure it gets activated when clicked
document.querySelector('.home').addEventListener('click', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));
    this.classList.add('active'); // Keep the active state for Home
});

// Toggle the down class when the More menu item is clicked
document.getElementById('more-menu').addEventListener('click', function() {
    var submenu = document.getElementById('more-submenu');
    var arrow = document.getElementById('more-arrow');
    submenu.classList.toggle('open');
    arrow.classList.toggle('left');
    arrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked More menu item
    this.classList.add('active');
});

// Tab switching
const buttons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

buttons.forEach(button => {
    button.addEventListener('click', function() {
        // Remove active class from all buttons
        buttons.forEach(btn => btn.classList.remove('active'));
        // Add active class to the clicked button
        this.classList.add('active');

        // Hide all tab contents
        tabContents.forEach(content => content.classList.remove('active'));
        // Show the next tab content
        const tabId = this.getAttribute('data-tab');
        document.getElementById(tabId).classList.add('active');
    });
});

//Filter Single text Function
function filterSingleTags() {
    var input = document.getElementById("single-tag");
    var filter = input.value.trim().toLowerCase();
    var dropdown = document.getElementById("single-dropdn");
    var items = dropdown.getElementsByClassName("dropdn-item");

    if (filter) {
        dropdown.style.display = "block";
    } else {
        dropdown.style.display = "none";
    }

    for (var i = 0; i < items.length; i++) {
        if (items[i].innerHTML.toLowerCase().indexOf(filter) > -1) {
            items[i].style.display = "";
        } else {
            items[i].style.display = "none";
        }
    }
}

// Function to select a single tag
function selectSingleTag(tag) {
    var input = document.getElementById("single-tag");
    input.value = tag; 
    document.getElementById("single-dropdn").style.display = "none"; // Hide the dropdown
    input.focus();
}

// Prevents backspace from deleting tags
function preventBackspace(event) {
    var input = document.getElementById("single-tag");
    var currentValue = input.value.trim();

    if (event.key === 'Backspace' && currentValue.length === 1) {
        event.preventDefault(); // Prevent deletion if only one character is present
        input.value = ''; // Clear the input field
    }
}

//Filter Multiple text Function
function filterTags() {
    var input = document.getElementById("tags");
    var filter = input.value.split(',').pop().trim().toLowerCase();
    var dropdown = document.getElementById("dropdn");
    var items = dropdown.getElementsByClassName("dropdn-item");

    if (filter) {
        dropdown.style.display = "block";
    } else {
        dropdown.style.display = "none";
    }

    for (var i = 0; i < items.length; i++) {
        if (items[i].innerHTML.toLowerCase().indexOf(filter) > -1) {
            items[i].style.display = "";
        } else {
            items[i].style.display = "none";
        }
    }
}

// Appends selected tag to input field with a comma
function selectTag(tag) {
    var input = document.getElementById("tags");
    var currentValue = input.value.split(',');

    // Replace the last input with the selected tag
    currentValue[currentValue.length - 1] = tag; 
    input.value = currentValue.join(', ') + ', '; 

    input.focus();  
    document.getElementById("dropdn").style.display = "none";
}

// Prevents backspace from deleting tags
function preventBackspace(event) {
    var input = document.getElementById("tags");
    var currentValue = input.value.trim();

    if (event.key === 'Backspace' && currentValue.endsWith(', ')) {
        event.preventDefault();
        input.value = currentValue.slice(0, -2);  // Remove the last comma and space
    }
}