// Add the down class to the arrow icon when the page loads
document.getElementById('more-arrow').classList.add('down'); // More menu arrow should point down by default
// Open the More submenu by default
document.getElementById('more-submenu').classList.add('open');

// Ensure Menu is selected in the More menu by default
document.querySelectorAll('#more-submenu .menu-item').forEach(item => {
    item.classList.remove('active'); // Deselect all
});
document.querySelector('#more-submenu .menu-item:nth-child(8)').classList.add('active'); // Select Menu

// Toggle the down class when the Employee menu item is clicked
document.getElementById('employee-menu').addEventListener('click', function() {
    var employeeSubmenu = document.getElementById('employee-submenu');
    var employeeArrow = document.getElementById('employee-arrow');
    var moreSubmenu = document.getElementById('more-submenu');
    var moreArrow = document.getElementById('more-arrow');
    
    // Close the More submenu and reset its arrow
    moreSubmenu.classList.remove('open');
    moreArrow.classList.remove('down');
    moreArrow.classList.add('left');
    document.getElementById('more-menu').classList.remove('active');

    // Open the Employee submenu and toggle the arrow
    employeeSubmenu.classList.toggle('open');
    employeeArrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked Employee menu item
    this.classList.add('active');
});

// For Home item, ensure it gets activated when clicked
document.querySelector('.home').addEventListener('click', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));
    this.classList.add('active'); 
});

// Toggle the down class when the More menu item is clicked
document.getElementById('more-menu').addEventListener('click', function() {
    var moreSubmenu = document.getElementById('more-submenu');
    var moreArrow = document.getElementById('more-arrow');
    var employeeSubmenu = document.getElementById('employee-submenu');
    var employeeArrow = document.getElementById('employee-arrow');
    
    // Close the Employee submenu and reset its arrow
    employeeSubmenu.classList.remove('open');
    employeeArrow.classList.remove('down');
    document.getElementById('employee-menu').classList.remove('active');

    // Open the More submenu and toggle the arrow
    moreSubmenu.classList.toggle('open');
    moreArrow.classList.toggle('left');
    moreArrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked More menu item
    this.classList.add('active');
});

// Popup functions
function openPopup(url, button, left, top) {
    // Open the URL in a new window with resizable option, specified size, and position
    window.open(url, '_blank', `width=350,height=300,resizable=yes,left=${left},top=${top}`);

    // Remove the active class from all buttons
    var buttons = document.querySelectorAll('.button-grid button');
    buttons.forEach(function(btn) {
        btn.classList.remove('active');
    });

    // Add the active class to the clicked button
    button.classList.add('active');
}

function duplicateTab() {
    // open in new tab the current tab
    window.open(window.location.href, '_blank');
}

function openModal() {
    var modal = document.getElementById("myModal");
    modal.style.display = "block";
    var modalContent = document.getElementById("modalContent");
    modalContent.style.animation = "dropDown 0.5s ease-out";
}

function closeModal() {
    var modal = document.getElementById("myModal");
    var modalContent = document.getElementById("modalContent");
    modalContent.style.animation = "dropUp 0.5s ease-out";
    setTimeout(function() {
        modal.style.display = "none";
    }, 500); 
}

function showAlert() {
    alert("This is an alert box");
}

function showConfirm() {
    confirm("Confirm Message Box");
}

function showPrompt() {
    var result = prompt("Enter Your Name:", "JALA Academy- A Place to find your Dream Job");
    var promptResult = document.getElementById("promptResult");
    if (result === null) {
        promptResult.textContent = "User cancelled the prompt.";
    } else {
        promptResult.textContent = result;
    }
}

document.getElementById('popupOne').onclick = function() {
    openPopup('https://www.google.com', this, 100, 20);
};

document.querySelector('.button-grid button:nth-child(2)').onclick = function() {
    openPopup('https://www.tutorialspoint.com/index.htm', this, 450, 20); // 
};

document.querySelector('.button-grid button:nth-child(3)').onclick = function() {
    openPopup('https://www.tutorialsteacher.com/', this, 800, 20); 
};

document.querySelector('.button-grid button:nth-child(4)').onclick = function() {
    openPopup('https://www.javatpoint.com/java-tutorial', this, 450, 20); 
};
