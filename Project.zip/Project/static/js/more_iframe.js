// Add the down class to the arrow icon when the page loads
document.getElementById('employee-arrow').classList.add('left'); // Employee should be closed by default
document.getElementById('more-arrow').classList.add('down'); // More menu arrow should point down by default

// Open the More submenu by default
document.getElementById('more-submenu').classList.add('open');

// Ensure Menu is selected in the More menu by default
document.querySelectorAll('#more-submenu .menu-item').forEach(item => {
    item.classList.remove('active'); // Deselect all
});
document.querySelector('#more-submenu .menu-item:nth-child(11)').classList.add('active'); // Select Menu

// Toggle the down class when the Employee menu item is clicked
document.getElementById('employee-menu').addEventListener('click', function() {
    var submenu = document.getElementById('employee-submenu');
    var arrow = document.getElementById('employee-arrow');
    submenu.classList.toggle('open');
    arrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked Employee menu item
    this.classList.add('active');
});

// For Home item, ensure it gets activated when clicked
document.querySelector('.home').addEventListener('click', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));
    this.classList.add('active'); // Keep the active state for Home
});

// Toggle the down class when the More menu item is clicked
document.getElementById('more-menu').addEventListener('click', function() {
    var submenu = document.getElementById('more-submenu');
    var arrow = document.getElementById('more-arrow');
    submenu.classList.toggle('open');
    arrow.classList.toggle('left');
    arrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    // Add active class to the clicked More menu item
    this.classList.add('active');
});

document.addEventListener("DOMContentLoaded", function() {
    function toggleSidebar() {
        const sidebar = document.querySelector('.m-sidebar');
        sidebar.classList.toggle('open');
    }

    // Attach the function to the button click
    document.querySelector('.bars').addEventListener('click', toggleSidebar);
});

document.getElementById('m-employee-menu').addEventListener('click', function() {
    const submenu = document.getElementById('m-employee-submenu');
    const arrow = document.getElementById('m-employee-arrow');

    // Toggle the expand class for submenu
    submenu.classList.toggle('expand');

    // Rotate the arrow
    arrow.classList.toggle('rotate');

    // Set max-height based on content
    if (submenu.classList.contains('expand')) {
        submenu.style.maxHeight = submenu.scrollHeight + 'px'; // Expand to fit content
    } else {
        submenu.style.maxHeight = '0'; // Collapse
    }
});

document.getElementById('m-more-menu').addEventListener('click', function() {
    const submenu1 = document.getElementById('m-more-submenu');
    const arrow1 = document.getElementById('m-more-arrow');

    // Toggle the expand class for submenu
    submenu1.classList.toggle('expand');

    // Rotate the arrow
    arrow1.classList.toggle('rotate');

    // Set max-height based on content
    if (submenu1.classList.contains('expand')) {
        submenu1.style.maxHeight = submenu.scrollHeight + 'px'; // Expand to fit content
    } else {
        submenu1.style.maxHeight = '0'; // Collapse
    }
});

document.getElementById('logout-button').addEventListener('click', function() {
    var iframe = document.querySelector('#mobile-view-container iframe');

    // Set the src attribute to login.html to load the login page
    iframe.src = 'login.html';
});