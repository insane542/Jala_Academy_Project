// Toggle the down class when the Employee menu item is clicked
document.getElementById('employee-menu').addEventListener('click', function() {
    var submenu = document.getElementById('employee-submenu');
    var arrow = document.getElementById('employee-arrow');
    submenu.classList.toggle('open');
    arrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    this.classList.add('active');
});

// For Home item, ensure it gets activated when clicked
document.querySelector('.home').addEventListener('click', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));
    this.classList.add('active'); 
});

// Toggle the down class when the More menu item is clicked
document.getElementById('more-menu').addEventListener('click', function() {
    var submenu = document.getElementById('more-submenu');
    var arrow = document.getElementById('more-arrow');
    submenu.classList.toggle('open');
    arrow.classList.toggle('left');
    arrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    this.classList.add('active');
});