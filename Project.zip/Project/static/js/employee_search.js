// Add the down class to the arrow icon when the page loads
document.getElementById('employee-arrow').classList.add('down'); // Employee arrow should point down by default
// Open the Employee submenu by default
document.getElementById('employee-submenu').classList.add('open');

// Ensure Menu is selected in the Employee menu by default
document.querySelectorAll('#employee-submenu .menu-item').forEach(item => {
    item.classList.remove('active'); 
});
document.querySelector('#employee-submenu .menu-item:nth-child(2)').classList.add('active'); // Select Menu

// Function to close all other menus
function closeOtherMenus(except) {
    if (except !== 'employee') {
        var employeeSubmenu = document.getElementById('employee-submenu');
        var employeeArrow = document.getElementById('employee-arrow');
        if (employeeSubmenu.classList.contains('open')) {
            employeeSubmenu.classList.remove('open');
            employeeArrow.classList.remove('down');
        }
    }

    if (except !== 'more') {
        var moreSubmenu = document.getElementById('more-submenu');
        var moreArrow = document.getElementById('more-arrow');
        if (moreSubmenu.classList.contains('open')) {
            moreSubmenu.classList.remove('open');
            moreArrow.classList.remove('down');
            moreArrow.classList.add('left');
        }
    }
}

// Toggle the Employee menu and ensure More menu closes
document.getElementById('employee-menu').addEventListener('click', function() {
    var submenu = document.getElementById('employee-submenu');
    var arrow = document.getElementById('employee-arrow');

    // Close the other menu (More)
    closeOtherMenus('employee');

    // Toggle the Employee submenu
    submenu.classList.toggle('open');
    arrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    this.classList.add('active');
});

// Toggle the More menu and ensure Employee menu closes
document.getElementById('more-menu').addEventListener('click', function() {
    var submenu = document.getElementById('more-submenu');
    var arrow = document.getElementById('more-arrow');

    // Close the other menu (Employee)
    closeOtherMenus('more');

    // Toggle the More submenu
    submenu.classList.toggle('open');
    arrow.classList.toggle('left');
    arrow.classList.toggle('down');

    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));

    this.classList.add('active');
});

// For Home item, ensure it gets activated when clicked
document.querySelector('.home').addEventListener('click', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(i => i.classList.remove('active'));
    this.classList.add('active'); // Keep the active state for Home
});